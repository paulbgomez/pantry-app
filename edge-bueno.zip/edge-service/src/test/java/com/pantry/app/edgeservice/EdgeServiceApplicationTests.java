package com.pantry.app.edgeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdgeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
